from pydantic import BaseModel, Field


class AIRequest(BaseModel):
    """
    Input received by the AI service.
    """

    message: str = Field(..., min_length=1)
    session_id: str | None = None


class AIResponse(BaseModel):
    """
    Standard response returned by the AI service.
    """

    answer: str
    session_id: str | None = None
    provider: str
