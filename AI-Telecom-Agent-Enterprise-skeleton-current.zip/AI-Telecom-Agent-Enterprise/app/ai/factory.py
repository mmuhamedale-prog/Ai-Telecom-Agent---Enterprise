from langchain_core.language_models import BaseChatModel

from app.ai.config import LLMConfig
from app.ai.providers import anthropic, openai, openrouter


PROVIDER_REGISTRY = {
    "openrouter": openrouter.create_llm,
    "openai": openai.create_llm,
    "anthropic": anthropic.create_llm,
}


class LLMFactory:

    @staticmethod
    def create(config: LLMConfig) -> BaseChatModel:
        try:
            creator = PROVIDER_REGISTRY[config.provider]
        except KeyError:
            raise ValueError(
                f"Unsupported LLM provider: {config.provider}"
            )

        return creator(config)
