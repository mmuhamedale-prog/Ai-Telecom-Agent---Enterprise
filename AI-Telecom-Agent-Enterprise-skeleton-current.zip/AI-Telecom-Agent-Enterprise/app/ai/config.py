import os

from dotenv import load_dotenv
from pydantic import BaseModel, Field


# Load variables from .env into the environment.
load_dotenv()


class LLMConfig(BaseModel):
    """
    Configuration for one LLM provider/model.
    """

    provider: str
    model: str
    api_key: str | None = None
    temperature: float = Field(
        default=0.2,
        ge=0.0,
        le=2.0,
    )


class AIConfig(BaseModel):
    """
    Configuration for the AI layer.
    """

    models: list[LLMConfig] = Field(min_length=1)
    primary: str = "openrouter"


def load_api_key(provider: str) -> str | None:
    """
    Return the API key associated with the selected provider.
    """

    keys = {
        "openrouter": os.getenv("OPENROUTER_API_KEY"),
        "openai": os.getenv("OPENAI_API_KEY"),
        "anthropic": os.getenv("ANTHROPIC_API_KEY"),
    }

    return keys.get(provider)
