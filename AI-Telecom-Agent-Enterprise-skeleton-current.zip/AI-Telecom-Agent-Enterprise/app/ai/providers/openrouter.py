from langchain_openai import ChatOpenAI

from app.ai.config import LLMConfig


def create_llm(config: LLMConfig) -> ChatOpenAI:
    return ChatOpenAI(
        model=config.model,
        api_key=config.api_key,
        temperature=config.temperature,
        base_url="https://openrouter.ai/api/v1",
    )
