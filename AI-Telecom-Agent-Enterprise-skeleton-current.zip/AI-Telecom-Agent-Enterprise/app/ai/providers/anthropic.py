from langchain_anthropic import ChatAnthropic

from app.ai.config import LLMConfig


def create_llm(config: LLMConfig) -> ChatAnthropic:
    return ChatAnthropic(
        model=config.model,
        api_key=config.api_key,
        temperature=config.temperature,
    )
