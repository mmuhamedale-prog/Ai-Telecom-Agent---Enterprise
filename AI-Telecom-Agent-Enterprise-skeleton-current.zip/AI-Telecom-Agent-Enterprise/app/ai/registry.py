from app.ai.config import AIConfig, LLMConfig


class LLMRegistry:
    """
    Stores and retrieves configured LLM models.
    """

    def __init__(self, config: AIConfig):
        self._models = {
            model.provider: model
            for model in config.models
        }

        self._primary = config.primary

    def get(self, provider: str) -> LLMConfig:
        """
        Return the configuration for a specific provider.
        """

        try:
            return self._models[provider]

        except KeyError:
            raise ValueError(
                f"LLM provider is not configured: {provider}"
            )

    def get_primary(self) -> LLMConfig:
        """
        Return the primary LLM configuration.
        """

        return self.get(self._primary)
