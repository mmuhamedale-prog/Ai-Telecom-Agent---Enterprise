from app.ai.config import AIConfig
from app.ai.factory import LLMFactory
from app.ai.registry import LLMRegistry
from app.ai.models import AIRequest, AIResponse
from app.ai.prompts import SYSTEM_PROMPT


class AIService:
    """
    Main service for interacting with the configured LLM.
    """

    def __init__(self, config: AIConfig):
        self.registry = LLMRegistry(config)
        self.llm = LLMFactory.create(
            self.registry.get_primary()
        )

    def chat(self, request: AIRequest) -> AIResponse:
        """
        Send a user message to the configured LLM.
        """

        messages = [
            ("system", SYSTEM_PROMPT),
            ("human", request.message),
        ]

        response = self.llm.invoke(messages)

        return AIResponse(
            answer=response.content,
            session_id=request.session_id,
            provider=self.registry.get_primary().provider,
        )
