from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from app.services.telecom_service import get_system_status

class ActionCheckSystemStatus(Action):
    def name(self) -> str:
        return "action_check_system_status"

    def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: dict,
    ):
        system = tracker.get_slot("system")
        line = tracker.get_slot("line")

        result = get_system_status(system, line)

        if not result["found"]:
            dispatcher.utter_message(
                text="I could not find that system or line."
            )
            return []

        dispatcher.utter_message(
            text=(
                f"{system} on {line} is {result['status']}. "
                f"Availability is {result['availability']}%. "
                f"Active alarms: {result['active_alarms']}."
            )
        )
        return []
