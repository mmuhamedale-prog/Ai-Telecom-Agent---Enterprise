# AI Telecom Smart Agent

Current snapshot through WebSocket -> Agent -> Rasa integration.

Flow:
Frontend -> WebSocket -> Agent -> Rasa -> Rule -> Action Server -> actions.py
-> telecom_service.py -> telecom data/API -> response -> WebSocket -> Frontend

First deterministic workflow:
"Check the CTC status on Cairo"

Expected:
intent = check_system_status
system = CTC
line = Cairo

The next validation stage is Action Server and full end-to-end/error testing.
