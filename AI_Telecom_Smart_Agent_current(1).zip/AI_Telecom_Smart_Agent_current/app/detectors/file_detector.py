from pathlib import Path

def detect_extension(filename: str) -> str:
    return Path(filename).suffix.lower()

def detect_content_type(filename: str) -> str:
    extension = detect_extension(filename)
    mapping = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".pdf": "application/pdf",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".zip": "application/zip",
    }
    return mapping.get(extension, "application/octet-stream")
