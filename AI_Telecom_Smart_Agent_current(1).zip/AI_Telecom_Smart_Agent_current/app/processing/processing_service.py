def process_input(content: bytes, content_type: str):
    # Processing coordinator placeholder.
    return {
        "content_type": content_type,
        "size": len(content),
    }
