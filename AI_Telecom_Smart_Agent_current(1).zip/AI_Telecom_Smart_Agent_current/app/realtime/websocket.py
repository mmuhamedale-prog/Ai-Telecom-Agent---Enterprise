from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from app.realtime.session import RealtimeSession
from app.realtime.agent import process_message

router = APIRouter()
sessions: dict[str, RealtimeSession] = {}

@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()

    current_session_id = str(id(websocket))
    current_session = RealtimeSession(
        session_id=current_session_id
    )
    sessions[current_session_id] = current_session

    try:
        while True:
            message = await websocket.receive_text()

            response = await process_message(
                message,
                current_session,
            )

            await websocket.send_text(response)

    except WebSocketDisconnect:
        current_session.active = False
        sessions.pop(current_session_id, None)
