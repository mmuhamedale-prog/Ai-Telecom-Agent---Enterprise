from datetime import datetime, timezone

class RealtimeSession:
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.started_at = datetime.now(timezone.utc)
        self.active = True
        self.conversation = []
