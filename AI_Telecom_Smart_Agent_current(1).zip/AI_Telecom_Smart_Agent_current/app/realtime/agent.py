import httpx

RASA_URL = "http://localhost:5005/webhooks/rest/webhook"

async def process_message(
    message: str,
    current_session,
) -> str:
    async with httpx.AsyncClient() as client:
        response = await client.post(
            RASA_URL,
            json={
                "sender": current_session.session_id,
                "message": message,
            },
        )

    response.raise_for_status()
    messages = response.json()

    if not messages:
        return ""

    return messages[0].get("text", "")
