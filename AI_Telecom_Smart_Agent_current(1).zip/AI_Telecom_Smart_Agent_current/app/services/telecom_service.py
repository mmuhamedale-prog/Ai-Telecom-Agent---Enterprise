import json
from pathlib import Path

DATA_FILE = Path("data/telecom_status.json")

def get_system_status(system: str, line: str) -> dict:
    with DATA_FILE.open("r", encoding="utf-8") as file:
        data = json.load(file)

    system_data = data.get(system)
    if not system_data:
        return {"found": False, "reason": "system_not_found"}

    status = system_data.get(line)
    if not status:
        return {"found": False, "reason": "line_not_found"}

    return {
        "found": True,
        "system": system,
        "line": line,
        **status,
    }
