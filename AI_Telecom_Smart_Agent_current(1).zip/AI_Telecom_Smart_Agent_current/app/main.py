from fastapi import FastAPI
from app.realtime.websocket import router as realtime_router

app = FastAPI(title="AI Telecom Smart Agent")
app.include_router(realtime_router)

@app.get("/")
async def root():
    return {"message": "Welcome to AI Telecom Smart Agent"}

@app.get("/health")
async def health():
    return {"status": "OK"}
