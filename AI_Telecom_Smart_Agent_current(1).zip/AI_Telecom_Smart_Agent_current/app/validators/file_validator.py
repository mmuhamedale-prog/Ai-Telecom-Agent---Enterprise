from pathlib import Path

MAX_FILE_SIZE = 10 * 1024 * 1024

EXPECTED_EXTENSIONS = {
    "image/jpeg": {".jpg", ".jpeg"},
    "image/png": {".png"},
    "application/pdf": {".pdf"},
}

def validate_file_size(file_bytes: bytes) -> bool:
    return len(file_bytes) <= MAX_FILE_SIZE

def validate_extension(filename: str, content_type: str) -> bool:
    extension = Path(filename).suffix.lower()
    expected = EXPECTED_EXTENSIONS.get(content_type, set())
    return extension in expected
