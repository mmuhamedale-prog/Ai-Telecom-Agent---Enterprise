# Current Flow

Frontend
-> websocket.py
-> agent.py
-> Rasa REST webhook
-> NLU
-> RulePolicy
-> Action Server
-> actions.py
-> telecom_service.py
-> telecom data/API
-> response
-> agent.py
-> websocket.py
-> Frontend

## Session

sessions is dict[str, RealtimeSession].
It maps session_id -> RealtimeSession object.

RealtimeSession currently contains:
- session_id
- started_at
- active
- conversation

## Message naming

message = current incoming user message.
response = current assistant response.
conversation = application-side conversation history.
Rasa tracker = Rasa conversation state including slots/entities/events.

The next incoming message reuses the local message variable; it does not erase stored conversation history or Rasa state.

## Rasa

nlu.yml = training examples.
config.yml = NLU pipeline configuration.
Training creates a model in models/.
domain.yml = declares intents/entities/slots/actions.
rules.yml = deterministic intent -> action behavior.
actions.py = custom action implementation.
endpoints.yml = Action Server endpoint.

## First workflow

Input: Check the CTC status on Cairo

intent: check_system_status
system: CTC
line: Cairo

Action:
action_check_system_status
-> get_system_status()
-> telecom_status.json

Expected:
CTC on Cairo is operational. Availability is 99.98%. Active alarms: 0.

## Pending validation

- Rasa unavailable
- Rasa HTTP 4xx/5xx and raise_for_status()
- empty Rasa response
- action failure
- telecom service failure
- WebSocket disconnect/session cleanup
